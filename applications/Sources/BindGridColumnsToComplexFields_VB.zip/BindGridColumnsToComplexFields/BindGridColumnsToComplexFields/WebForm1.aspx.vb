﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub EntityDataSource1_QueryCreated(sender As Object, e As QueryCreatedEventArgs) Handles EntityDataSource1.QueryCreated
        e.Query = TryCast(e.Query, Objects.ObjectQuery(Of Product)).Include("Category")
    End Sub
End Class